(* A file to contain church encodings for use in the project *)

open Lambdaast

